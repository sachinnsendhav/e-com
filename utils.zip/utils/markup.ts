const createMarkup = (content: string) => {
  return {__html: content};
}

export default createMarkup;