/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../store */ \"./store/index.ts\");\n/* harmony import */ var swiper_swiper_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swiper/swiper.scss */ \"./node_modules/swiper/swiper.scss\");\n/* harmony import */ var swiper_swiper_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_swiper_scss__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var rc_slider_assets_index_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rc-slider/assets/index.css */ \"./node_modules/rc-slider/assets/index.css\");\n/* harmony import */ var rc_slider_assets_index_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rc_slider_assets_index_css__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var react_rater_lib_react_rater_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-rater/lib/react-rater.css */ \"./node_modules/react-rater/lib/react-rater.css\");\n/* harmony import */ var react_rater_lib_react_rater_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_rater_lib_react_rater_css__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _assets_css_styles_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../assets/css/styles.scss */ \"./assets/css/styles.scss\");\n/* harmony import */ var _assets_css_styles_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_assets_css_styles_scss__WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var _utils_gtag__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../utils/gtag */ \"./utils/gtag.ts\");\n\n\n\n\n// global styles\n\n\n\n\n\nconst isProduction = \"development\" === \"production\";\n// only events on production\nif (isProduction) {\n    // Notice how we track pageview when route is changed\n    next_router__WEBPACK_IMPORTED_MODULE_2___default().events.on(\"routeChangeComplete\", (url)=>_utils_gtag__WEBPACK_IMPORTED_MODULE_8__.pageview(url)\n    );\n}\nconst MyApp = ({ Component , pageProps  })=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\admin\\\\vtex-nextJS\\\\next-ecommerce\\\\pages\\\\_app.tsx\",\n            lineNumber: 27,\n            columnNumber: 5\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\admin\\\\vtex-nextJS\\\\next-ecommerce\\\\pages\\\\_app.tsx\",\n        lineNumber: 26,\n        columnNumber: 3\n    }, undefined)\n;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_store__WEBPACK_IMPORTED_MODULE_3__.wrapper.withRedux(MyApp));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQXdDO0FBQ1A7QUFDQTtBQUtqQyxnQkFBZ0I7QUFDWTtBQUNRO0FBQ0s7QUFDTjtBQUVLO0FBRXhDLE1BQU1LLFlBQVksR0FBR0MsYUFmUixLQWVpQyxZQUFZO0FBRTFELDRCQUE0QjtBQUM1QixJQUFHRCxZQUFZLEVBQUU7SUFFZixxREFBcUQ7SUFDckRILDREQUFnQixDQUFDLHFCQUFxQixFQUFFLENBQUNPLEdBQVcsR0FBS0wsaURBQWEsQ0FBQ0ssR0FBRyxDQUFDO0lBQUEsQ0FBQyxDQUFDO0NBQzlFO0FBRUQsTUFBTUUsS0FBSyxHQUFHLENBQUMsRUFBRUMsU0FBUyxHQUFFQyxTQUFTLEdBQVksaUJBQy9DLDhEQUFDWiwyQ0FBUTtrQkFDUCw0RUFBQ1csU0FBUztZQUFFLEdBQUdDLFNBQVM7Ozs7O3FCQUFJOzs7OztpQkFDbkI7QUFDWDtBQUVGLGlFQUFlVixxREFBaUIsQ0FBQ1EsS0FBSyxDQUFDLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWVjb21tZXJjZS8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IEZyYWdtZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHt3cmFwcGVyfSBmcm9tICcuLi9zdG9yZSc7XHJcblxyXG4vLyB0eXBlc1xyXG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xyXG5cclxuLy8gZ2xvYmFsIHN0eWxlc1xyXG5pbXBvcnQgJ3N3aXBlci9zd2lwZXIuc2Nzcyc7XHJcbmltcG9ydCAncmMtc2xpZGVyL2Fzc2V0cy9pbmRleC5jc3MnO1xyXG5pbXBvcnQgJ3JlYWN0LXJhdGVyL2xpYi9yZWFjdC1yYXRlci5jc3MnO1xyXG5pbXBvcnQgJy4uL2Fzc2V0cy9jc3Mvc3R5bGVzLnNjc3MnO1xyXG5cclxuaW1wb3J0ICogYXMgZ3RhZyBmcm9tICcuLy4uL3V0aWxzL2d0YWcnO1xyXG5cclxuY29uc3QgaXNQcm9kdWN0aW9uID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJztcclxuXHJcbi8vIG9ubHkgZXZlbnRzIG9uIHByb2R1Y3Rpb25cclxuaWYoaXNQcm9kdWN0aW9uKSB7XHJcbiAgXHJcbiAgLy8gTm90aWNlIGhvdyB3ZSB0cmFjayBwYWdldmlldyB3aGVuIHJvdXRlIGlzIGNoYW5nZWRcclxuICBSb3V0ZXIuZXZlbnRzLm9uKCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgKHVybDogc3RyaW5nKSA9PiBndGFnLnBhZ2V2aWV3KHVybCkpO1xyXG59XHJcblxyXG5jb25zdCBNeUFwcCA9ICh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSA9PiAoXHJcbiAgPEZyYWdtZW50PlxyXG4gICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxyXG4gIDwvRnJhZ21lbnQ+XHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB3cmFwcGVyLndpdGhSZWR1eChNeUFwcCk7Il0sIm5hbWVzIjpbIlJlYWN0IiwiRnJhZ21lbnQiLCJSb3V0ZXIiLCJ3cmFwcGVyIiwiZ3RhZyIsImlzUHJvZHVjdGlvbiIsInByb2Nlc3MiLCJldmVudHMiLCJvbiIsInVybCIsInBhZ2V2aWV3IiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJ3aXRoUmVkdXgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./store/index.ts":
/*!************************!*\
  !*** ./store/index.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"wrapper\": () => (/* binding */ wrapper)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-redux-wrapper */ \"next-redux-wrapper\");\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _reducers_cart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reducers/cart */ \"./store/reducers/cart.ts\");\n/* harmony import */ var _reducers_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reducers/user */ \"./store/reducers/user.ts\");\n/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! redux-persist/lib/storage */ \"redux-persist/lib/storage\");\n/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! redux-persist */ \"redux-persist\");\n/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\n//COMBINING ALL REDUCERS\nconst reducer = {\n    cart: _reducers_cart__WEBPACK_IMPORTED_MODULE_2__[\"default\"],\n    user: _reducers_user__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n};\nconst rootReducer = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.combineReducers)({\n    cart: _reducers_cart__WEBPACK_IMPORTED_MODULE_2__[\"default\"],\n    user: _reducers_user__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n});\nlet store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n    reducer\n});\nconst makeStore = ({ isServer  })=>{\n    if (isServer) {\n        //If it's on server side, create a store\n        return store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n            reducer\n        });\n    } else {\n        //If it's on client side, create a store which will persist\n        const persistConfig = {\n            key: \"shoppingcart\",\n            whitelist: [\n                \"cart\",\n                \"user\"\n            ],\n            storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default())\n        };\n        const persistedReducer = (0,redux_persist__WEBPACK_IMPORTED_MODULE_5__.persistReducer)(persistConfig, rootReducer); // Create a new reducer with our existing reducer\n        store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n            reducer: persistedReducer\n        }); // Creating the store again\n        // @ts-ignore:next-line\n        store.__persistor = (0,redux_persist__WEBPACK_IMPORTED_MODULE_5__.persistStore)(store); // This creates a persistor object & push that persisted object to .__persistor, so that we can avail the persistability feature\n        return store;\n    }\n};\n// export an assembled wrapper\n// @ts-ignore:next-line\nconst wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(makeStore, {\n    debug: true\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFrRTtBQUNmO0FBQ1Q7QUFDQTtBQUNLO0FBSXpCO0FBRXRCLHdCQUF3QjtBQUN4QixNQUFNUSxPQUFPLEdBQUc7SUFDZEMsSUFBSSxFQUFFTixzREFBVztJQUNqQk8sSUFBSSxFQUFFTixzREFBVztDQUNsQjtBQUVELE1BQU1PLFdBQVcsR0FBR1YsaUVBQWUsQ0FBQztJQUNsQ1EsSUFBSSxFQUFFTixzREFBVztJQUNqQk8sSUFBSSxFQUFFTixzREFBVztDQUNsQixDQUFDO0FBRUYsSUFBSVEsS0FBSyxHQUFHWixnRUFBYyxDQUFDO0lBQ3pCUSxPQUFPO0NBQ1IsQ0FBQztBQUVGLE1BQU1LLFNBQVMsR0FBRyxDQUFDLEVBQUVDLFFBQVEsR0FBeUIsR0FBSztJQUN6RCxJQUFJQSxRQUFRLEVBQUU7UUFDWix3Q0FBd0M7UUFDeEMsT0FBT0YsS0FBSyxHQUFHWixnRUFBYyxDQUFDO1lBQzVCUSxPQUFPO1NBQ1IsQ0FBQyxDQUFDO0tBQ0osTUFBTTtRQUNMLDJEQUEyRDtRQUMzRCxNQUFNTyxhQUFhLEdBQUc7WUFDcEJDLEdBQUcsRUFBRSxjQUFjO1lBQ25CQyxTQUFTLEVBQUU7Z0JBQUMsTUFBTTtnQkFBRSxNQUFNO2FBQUM7WUFDM0JaLE9BQU87U0FDUjtRQUVELE1BQU1hLGdCQUFnQixHQUFHWCw2REFBYyxDQUFDUSxhQUFhLEVBQUVKLFdBQVcsQ0FBQyxFQUFFLGlEQUFpRDtRQUV0SEMsS0FBSyxHQUFHWixnRUFBYyxDQUFDO1lBQ3JCUSxPQUFPLEVBQUVVLGdCQUFnQjtTQUMxQixDQUFDLENBQUMsQ0FBQywyQkFBMkI7UUFFL0IsdUJBQXVCO1FBQ3ZCTixLQUFLLENBQUNPLFdBQVcsR0FBR2IsMkRBQVksQ0FBQ00sS0FBSyxDQUFDLENBQUMsQ0FBQyxnSUFBZ0k7UUFFekssT0FBT0EsS0FBSyxDQUFDO0tBQ2Q7Q0FDRjtBQUVELDhCQUE4QjtBQUM5Qix1QkFBdUI7QUFDaEIsTUFBTVEsT0FBTyxHQUFHbEIsaUVBQWEsQ0FBQ1csU0FBUyxFQUFFO0lBQUNRLEtBQUssRUFBRSxJQUFJO0NBQUMsQ0FBQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1lY29tbWVyY2UvLi9zdG9yZS9pbmRleC50cz9iNWIzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNvbmZpZ3VyZVN0b3JlLCBjb21iaW5lUmVkdWNlcnMgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0J1xyXG5pbXBvcnQgeyBjcmVhdGVXcmFwcGVyIH0gZnJvbSAnbmV4dC1yZWR1eC13cmFwcGVyJztcclxuaW1wb3J0IGNhcnRSZWR1Y2VyIGZyb20gJy4vcmVkdWNlcnMvY2FydCc7XHJcbmltcG9ydCB1c2VyUmVkdWNlciBmcm9tICcuL3JlZHVjZXJzL3VzZXInO1xyXG5pbXBvcnQgc3RvcmFnZSBmcm9tICdyZWR1eC1wZXJzaXN0L2xpYi9zdG9yYWdlJ1xyXG5pbXBvcnQge1xyXG4gIHBlcnNpc3RTdG9yZSxcclxuICBwZXJzaXN0UmVkdWNlcixcclxufSBmcm9tICdyZWR1eC1wZXJzaXN0J1xyXG5cclxuLy9DT01CSU5JTkcgQUxMIFJFRFVDRVJTXHJcbmNvbnN0IHJlZHVjZXIgPSB7XHJcbiAgY2FydDogY2FydFJlZHVjZXIsXHJcbiAgdXNlcjogdXNlclJlZHVjZXJcclxufVxyXG5cclxuY29uc3Qgcm9vdFJlZHVjZXIgPSBjb21iaW5lUmVkdWNlcnMoe1xyXG4gIGNhcnQ6IGNhcnRSZWR1Y2VyLFxyXG4gIHVzZXI6IHVzZXJSZWR1Y2VyLFxyXG59KVxyXG5cclxubGV0IHN0b3JlID0gY29uZmlndXJlU3RvcmUoeyBcclxuICByZWR1Y2VyLFxyXG59KTtcclxuXHJcbmNvbnN0IG1ha2VTdG9yZSA9ICh7IGlzU2VydmVyIH06IHsgaXNTZXJ2ZXI6IEJvb2xlYW4gfSkgPT4ge1xyXG4gIGlmIChpc1NlcnZlcikge1xyXG4gICAgLy9JZiBpdCdzIG9uIHNlcnZlciBzaWRlLCBjcmVhdGUgYSBzdG9yZVxyXG4gICAgcmV0dXJuIHN0b3JlID0gY29uZmlndXJlU3RvcmUoeyBcclxuICAgICAgcmVkdWNlcixcclxuICAgIH0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICAvL0lmIGl0J3Mgb24gY2xpZW50IHNpZGUsIGNyZWF0ZSBhIHN0b3JlIHdoaWNoIHdpbGwgcGVyc2lzdFxyXG4gICAgY29uc3QgcGVyc2lzdENvbmZpZyA9IHtcclxuICAgICAga2V5OiBcInNob3BwaW5nY2FydFwiLFxyXG4gICAgICB3aGl0ZWxpc3Q6IFtcImNhcnRcIiwgXCJ1c2VyXCJdLCAvLyBvbmx5IGNvdW50ZXIgd2lsbCBiZSBwZXJzaXN0ZWQsIGFkZCBvdGhlciByZWR1Y2VycyBpZiBuZWVkZWRcclxuICAgICAgc3RvcmFnZSwgLy8gaWYgbmVlZGVkLCB1c2UgYSBzYWZlciBzdG9yYWdlXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHBlcnNpc3RlZFJlZHVjZXIgPSBwZXJzaXN0UmVkdWNlcihwZXJzaXN0Q29uZmlnLCByb290UmVkdWNlcik7IC8vIENyZWF0ZSBhIG5ldyByZWR1Y2VyIHdpdGggb3VyIGV4aXN0aW5nIHJlZHVjZXJcclxuXHJcbiAgICBzdG9yZSA9IGNvbmZpZ3VyZVN0b3JlKHsgXHJcbiAgICAgIHJlZHVjZXI6IHBlcnNpc3RlZFJlZHVjZXIsXHJcbiAgICB9KTsgLy8gQ3JlYXRpbmcgdGhlIHN0b3JlIGFnYWluXHJcblxyXG4gICAgLy8gQHRzLWlnbm9yZTpuZXh0LWxpbmVcclxuICAgIHN0b3JlLl9fcGVyc2lzdG9yID0gcGVyc2lzdFN0b3JlKHN0b3JlKTsgLy8gVGhpcyBjcmVhdGVzIGEgcGVyc2lzdG9yIG9iamVjdCAmIHB1c2ggdGhhdCBwZXJzaXN0ZWQgb2JqZWN0IHRvIC5fX3BlcnNpc3Rvciwgc28gdGhhdCB3ZSBjYW4gYXZhaWwgdGhlIHBlcnNpc3RhYmlsaXR5IGZlYXR1cmVcclxuXHJcbiAgICByZXR1cm4gc3RvcmU7XHJcbiAgfVxyXG59O1xyXG5cclxuLy8gZXhwb3J0IGFuIGFzc2VtYmxlZCB3cmFwcGVyXHJcbi8vIEB0cy1pZ25vcmU6bmV4dC1saW5lXHJcbmV4cG9ydCBjb25zdCB3cmFwcGVyID0gY3JlYXRlV3JhcHBlcihtYWtlU3RvcmUsIHtkZWJ1ZzogdHJ1ZX0pO1xyXG5cclxuLy8gSW5mZXIgdGhlIGBSb290U3RhdGVgIGFuZCBgQXBwRGlzcGF0Y2hgIHR5cGVzIGZyb20gdGhlIHN0b3JlIGl0c2VsZlxyXG5leHBvcnQgdHlwZSBSb290U3RhdGUgPSBSZXR1cm5UeXBlPHR5cGVvZiBzdG9yZS5nZXRTdGF0ZT5cclxuXHJcbi8vIEluZmVycmVkIHR5cGU6IHtwb3N0czogUG9zdHNTdGF0ZSwgY29tbWVudHM6IENvbW1lbnRzU3RhdGUsIHVzZXJzOiBVc2Vyc1N0YXRlfVxyXG5leHBvcnQgdHlwZSBBcHBEaXNwYXRjaCA9IHR5cGVvZiBzdG9yZS5kaXNwYXRjaCJdLCJuYW1lcyI6WyJjb25maWd1cmVTdG9yZSIsImNvbWJpbmVSZWR1Y2VycyIsImNyZWF0ZVdyYXBwZXIiLCJjYXJ0UmVkdWNlciIsInVzZXJSZWR1Y2VyIiwic3RvcmFnZSIsInBlcnNpc3RTdG9yZSIsInBlcnNpc3RSZWR1Y2VyIiwicmVkdWNlciIsImNhcnQiLCJ1c2VyIiwicm9vdFJlZHVjZXIiLCJzdG9yZSIsIm1ha2VTdG9yZSIsImlzU2VydmVyIiwicGVyc2lzdENvbmZpZyIsImtleSIsIndoaXRlbGlzdCIsInBlcnNpc3RlZFJlZHVjZXIiLCJfX3BlcnNpc3RvciIsIndyYXBwZXIiLCJkZWJ1ZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./store/index.ts\n");

/***/ }),

/***/ "./store/reducers/cart.ts":
/*!********************************!*\
  !*** ./store/reducers/cart.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"addProduct\": () => (/* binding */ addProduct),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"removeProduct\": () => (/* binding */ removeProduct),\n/* harmony export */   \"setCount\": () => (/* binding */ setCount)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n\nconst initialState = {\n    cartItems: []\n};\nconst indexSameProduct = (state, action)=>{\n    const sameProduct = (product)=>product.id === action.id && product.color === action.color && product.size === action.size\n    ;\n    return state.cartItems.findIndex(sameProduct);\n};\nconst cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n    name: \"cart\",\n    initialState,\n    reducers: {\n        addProduct: (state, action)=>{\n            const cartItems = state.cartItems;\n            // find index of product\n            const index = indexSameProduct(state, action.payload.product);\n            if (index !== -1) {\n                cartItems[index].count += action.payload.count;\n                return;\n            }\n            return {\n                ...state,\n                cartItems: [\n                    ...state.cartItems,\n                    action.payload.product\n                ]\n            };\n        },\n        removeProduct (state, action) {\n            // find index of product\n            state.cartItems.splice(indexSameProduct(state, action.payload), 1);\n        },\n        setCount (state, action) {\n            // find index and add new count on product count\n            const indexItem = indexSameProduct(state, action.payload.product);\n            state.cartItems[indexItem].count = action.payload.count;\n        }\n    }\n});\nconst { addProduct , removeProduct , setCount  } = cartSlice.actions;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9yZWR1Y2Vycy9jYXJ0LnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE2RDtBQU83RCxNQUFNQyxZQUFZLEdBQUc7SUFDbkJDLFNBQVMsRUFBRSxFQUFFO0NBQ2Q7QUFFRCxNQUFNQyxnQkFBZ0IsR0FBRyxDQUFDQyxLQUFnQixFQUFFQyxNQUF3QixHQUFLO0lBQ3ZFLE1BQU1DLFdBQVcsR0FBRyxDQUFDQyxPQUF5QixHQUM1Q0EsT0FBTyxDQUFDQyxFQUFFLEtBQUtILE1BQU0sQ0FBQ0csRUFBRSxJQUN4QkQsT0FBTyxDQUFDRSxLQUFLLEtBQUtKLE1BQU0sQ0FBQ0ksS0FBSyxJQUM5QkYsT0FBTyxDQUFDRyxJQUFJLEtBQUtMLE1BQU0sQ0FBQ0ssSUFBSTtJQUM1QjtJQUVGLE9BQU9OLEtBQUssQ0FBQ0YsU0FBUyxDQUFDUyxTQUFTLENBQUNMLFdBQVcsQ0FBQztDQUM5QztBQU9ELE1BQU1NLFNBQVMsR0FBR1osNkRBQVcsQ0FBQztJQUM1QmEsSUFBSSxFQUFFLE1BQU07SUFDWlosWUFBWTtJQUNaYSxRQUFRLEVBQUU7UUFDUkMsVUFBVSxFQUFFLENBQUNYLEtBQUssRUFBRUMsTUFBcUMsR0FBSztZQUM1RCxNQUFNSCxTQUFTLEdBQUdFLEtBQUssQ0FBQ0YsU0FBUztZQUVqQyx3QkFBd0I7WUFDeEIsTUFBTWMsS0FBSyxHQUFHYixnQkFBZ0IsQ0FBQ0MsS0FBSyxFQUFFQyxNQUFNLENBQUNZLE9BQU8sQ0FBQ1YsT0FBTyxDQUFDO1lBRTdELElBQUdTLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDZmQsU0FBUyxDQUFDYyxLQUFLLENBQUMsQ0FBQ0UsS0FBSyxJQUFJYixNQUFNLENBQUNZLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDO2dCQUMvQyxPQUFPO2FBQ1I7WUFFRCxPQUFPO2dCQUNMLEdBQUdkLEtBQUs7Z0JBQ1JGLFNBQVMsRUFBRTt1QkFBSUUsS0FBSyxDQUFDRixTQUFTO29CQUFFRyxNQUFNLENBQUNZLE9BQU8sQ0FBQ1YsT0FBTztpQkFBRTthQUN6RCxDQUFDO1NBQ0g7UUFDRFksYUFBYSxFQUFDZixLQUFLLEVBQUVDLE1BQXVDLEVBQUU7WUFDNUQsd0JBQXdCO1lBQ3hCRCxLQUFLLENBQUNGLFNBQVMsQ0FBQ2tCLE1BQU0sQ0FBQ2pCLGdCQUFnQixDQUFDQyxLQUFLLEVBQUVDLE1BQU0sQ0FBQ1ksT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDcEU7UUFDREksUUFBUSxFQUFDakIsS0FBSyxFQUFFQyxNQUFxQyxFQUFFO1lBQ3JELGdEQUFnRDtZQUNoRCxNQUFNaUIsU0FBUyxHQUFHbkIsZ0JBQWdCLENBQUNDLEtBQUssRUFBRUMsTUFBTSxDQUFDWSxPQUFPLENBQUNWLE9BQU8sQ0FBQztZQUNqRUgsS0FBSyxDQUFDRixTQUFTLENBQUNvQixTQUFTLENBQUMsQ0FBQ0osS0FBSyxHQUFHYixNQUFNLENBQUNZLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDO1NBQ3pEO0tBQ0Y7Q0FDRixDQUFDO0FBRUssTUFBTSxFQUFFSCxVQUFVLEdBQUVJLGFBQWEsR0FBRUUsUUFBUSxHQUFFLEdBQUdULFNBQVMsQ0FBQ1csT0FBTztBQUN4RSxpRUFBZVgsU0FBUyxDQUFDWSxPQUFPIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dC1lY29tbWVyY2UvLi9zdG9yZS9yZWR1Y2Vycy9jYXJ0LnRzP2EyMzgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlU2xpY2UsIFBheWxvYWRBY3Rpb24gfSBmcm9tICdAcmVkdXhqcy90b29sa2l0J1xyXG5pbXBvcnQgeyBQcm9kdWN0U3RvcmVUeXBlIH0gZnJvbSAndHlwZXMnO1xyXG5cclxuaW50ZXJmYWNlIENhcnRUeXBlcyB7XHJcbiAgY2FydEl0ZW1zOiBQcm9kdWN0U3RvcmVUeXBlW11cclxufVxyXG5cclxuY29uc3QgaW5pdGlhbFN0YXRlID0geyBcclxuICBjYXJ0SXRlbXM6IFtdIFxyXG59IGFzIENhcnRUeXBlcztcclxuXHJcbmNvbnN0IGluZGV4U2FtZVByb2R1Y3QgPSAoc3RhdGU6IENhcnRUeXBlcywgYWN0aW9uOiBQcm9kdWN0U3RvcmVUeXBlKSA9PiB7XHJcbiAgY29uc3Qgc2FtZVByb2R1Y3QgPSAocHJvZHVjdDogUHJvZHVjdFN0b3JlVHlwZSkgPT4gKFxyXG4gICAgcHJvZHVjdC5pZCA9PT0gYWN0aW9uLmlkICYmIFxyXG4gICAgcHJvZHVjdC5jb2xvciA9PT0gYWN0aW9uLmNvbG9yICYmIFxyXG4gICAgcHJvZHVjdC5zaXplID09PSBhY3Rpb24uc2l6ZVxyXG4gICk7XHJcblxyXG4gIHJldHVybiBzdGF0ZS5jYXJ0SXRlbXMuZmluZEluZGV4KHNhbWVQcm9kdWN0KVxyXG59O1xyXG5cclxudHlwZSBBZGRQcm9kdWN0VHlwZSA9IHtcclxuICBwcm9kdWN0OiBQcm9kdWN0U3RvcmVUeXBlLFxyXG4gIGNvdW50OiBudW1iZXIsXHJcbn1cclxuXHJcbmNvbnN0IGNhcnRTbGljZSA9IGNyZWF0ZVNsaWNlKHtcclxuICBuYW1lOiAnY2FydCcsXHJcbiAgaW5pdGlhbFN0YXRlLFxyXG4gIHJlZHVjZXJzOiB7XHJcbiAgICBhZGRQcm9kdWN0OiAoc3RhdGUsIGFjdGlvbjogUGF5bG9hZEFjdGlvbjxBZGRQcm9kdWN0VHlwZT4pID0+IHtcclxuICAgICAgY29uc3QgY2FydEl0ZW1zID0gc3RhdGUuY2FydEl0ZW1zO1xyXG5cclxuICAgICAgLy8gZmluZCBpbmRleCBvZiBwcm9kdWN0XHJcbiAgICAgIGNvbnN0IGluZGV4ID0gaW5kZXhTYW1lUHJvZHVjdChzdGF0ZSwgYWN0aW9uLnBheWxvYWQucHJvZHVjdCk7XHJcblxyXG4gICAgICBpZihpbmRleCAhPT0gLTEpIHtcclxuICAgICAgICBjYXJ0SXRlbXNbaW5kZXhdLmNvdW50ICs9IGFjdGlvbi5wYXlsb2FkLmNvdW50O1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICBjYXJ0SXRlbXM6IFsuLi5zdGF0ZS5jYXJ0SXRlbXMsIGFjdGlvbi5wYXlsb2FkLnByb2R1Y3QgXVxyXG4gICAgICB9O1xyXG4gICAgfSxcclxuICAgIHJlbW92ZVByb2R1Y3Qoc3RhdGUsIGFjdGlvbjogUGF5bG9hZEFjdGlvbjxQcm9kdWN0U3RvcmVUeXBlPikge1xyXG4gICAgICAvLyBmaW5kIGluZGV4IG9mIHByb2R1Y3RcclxuICAgICAgc3RhdGUuY2FydEl0ZW1zLnNwbGljZShpbmRleFNhbWVQcm9kdWN0KHN0YXRlLCBhY3Rpb24ucGF5bG9hZCksIDEpO1xyXG4gICAgfSxcclxuICAgIHNldENvdW50KHN0YXRlLCBhY3Rpb246IFBheWxvYWRBY3Rpb248QWRkUHJvZHVjdFR5cGU+KSB7XHJcbiAgICAgIC8vIGZpbmQgaW5kZXggYW5kIGFkZCBuZXcgY291bnQgb24gcHJvZHVjdCBjb3VudFxyXG4gICAgICBjb25zdCBpbmRleEl0ZW0gPSBpbmRleFNhbWVQcm9kdWN0KHN0YXRlLCBhY3Rpb24ucGF5bG9hZC5wcm9kdWN0KTtcclxuICAgICAgc3RhdGUuY2FydEl0ZW1zW2luZGV4SXRlbV0uY291bnQgPSBhY3Rpb24ucGF5bG9hZC5jb3VudDtcclxuICAgIH0sXHJcbiAgfSxcclxufSlcclxuXHJcbmV4cG9ydCBjb25zdCB7IGFkZFByb2R1Y3QsIHJlbW92ZVByb2R1Y3QsIHNldENvdW50IH0gPSBjYXJ0U2xpY2UuYWN0aW9uc1xyXG5leHBvcnQgZGVmYXVsdCBjYXJ0U2xpY2UucmVkdWNlciJdLCJuYW1lcyI6WyJjcmVhdGVTbGljZSIsImluaXRpYWxTdGF0ZSIsImNhcnRJdGVtcyIsImluZGV4U2FtZVByb2R1Y3QiLCJzdGF0ZSIsImFjdGlvbiIsInNhbWVQcm9kdWN0IiwicHJvZHVjdCIsImlkIiwiY29sb3IiLCJzaXplIiwiZmluZEluZGV4IiwiY2FydFNsaWNlIiwibmFtZSIsInJlZHVjZXJzIiwiYWRkUHJvZHVjdCIsImluZGV4IiwicGF5bG9hZCIsImNvdW50IiwicmVtb3ZlUHJvZHVjdCIsInNwbGljZSIsInNldENvdW50IiwiaW5kZXhJdGVtIiwiYWN0aW9ucyIsInJlZHVjZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./store/reducers/cart.ts\n");

/***/ }),

/***/ "./store/reducers/user.ts":
/*!********************************!*\
  !*** ./store/reducers/user.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"setUserLogged\": () => (/* binding */ setUserLogged),\n/* harmony export */   \"toggleFavProduct\": () => (/* binding */ toggleFavProduct)\n/* harmony export */ });\n/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ \"lodash\");\n/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst initialState = {\n    user: {\n        name: \"Lucas Pulliese\"\n    },\n    favProducts: []\n};\nconst userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({\n    name: \"user\",\n    initialState,\n    reducers: {\n        toggleFavProduct (state, action) {\n            const index = state.favProducts.includes(action.payload.id);\n            if (!index) {\n                state.favProducts.push(action.payload.id);\n                return;\n            }\n            (0,lodash__WEBPACK_IMPORTED_MODULE_0__.remove)(state.favProducts, (id)=>id === action.payload.id\n            );\n        },\n        setUserLogged (state, action) {\n            const index = state.favProducts.includes(action.payload.id);\n            if (!index) {\n                state.favProducts.push(action.payload.id);\n                return {\n                    ...state,\n                    favProducts: state.favProducts\n                };\n            }\n            (0,lodash__WEBPACK_IMPORTED_MODULE_0__.remove)(state.favProducts, (id)=>id === action.payload.id\n            );\n            return {\n                ...state,\n                favProducts: state.favProducts\n            };\n        }\n    }\n});\nconst { toggleFavProduct , setUserLogged  } = userSlice.actions;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9yZWR1Y2Vycy91c2VyLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBZ0M7QUFFNkI7QUFxQjdELE1BQU1FLFlBQVksR0FBRztJQUNuQkMsSUFBSSxFQUFFO1FBQ0pDLElBQUksRUFBRSxnQkFBZ0I7S0FDdkI7SUFDREMsV0FBVyxFQUFFLEVBQUU7Q0FDaEI7QUFFRCxNQUFNQyxTQUFTLEdBQUdMLDZEQUFXLENBQUM7SUFDNUJHLElBQUksRUFBRSxNQUFNO0lBQ1pGLFlBQVk7SUFDWkssUUFBUSxFQUFFO1FBQ1JDLGdCQUFnQixFQUFDQyxLQUFLLEVBQUVDLE1BQW9DLEVBQUU7WUFDNUQsTUFBTUMsS0FBSyxHQUFHRixLQUFLLENBQUNKLFdBQVcsQ0FBQ08sUUFBUSxDQUFDRixNQUFNLENBQUNHLE9BQU8sQ0FBQ0MsRUFBRSxDQUFDO1lBRTNELElBQUcsQ0FBQ0gsS0FBSyxFQUFFO2dCQUNURixLQUFLLENBQUNKLFdBQVcsQ0FBQ1UsSUFBSSxDQUFDTCxNQUFNLENBQUNHLE9BQU8sQ0FBQ0MsRUFBRSxDQUFDLENBQUM7Z0JBRTFDLE9BQU87YUFDUjtZQUVEZCw4Q0FBTSxDQUFDUyxLQUFLLENBQUNKLFdBQVcsRUFBRVMsQ0FBQUEsRUFBRSxHQUFJQSxFQUFFLEtBQUtKLE1BQU0sQ0FBQ0csT0FBTyxDQUFDQyxFQUFFO1lBQUEsQ0FBQyxDQUFDO1NBQzNEO1FBQ0RFLGFBQWEsRUFBQ1AsS0FBSyxFQUFFQyxNQUFrQyxFQUFFO1lBQ3ZELE1BQU1DLEtBQUssR0FBR0YsS0FBSyxDQUFDSixXQUFXLENBQUNPLFFBQVEsQ0FBQ0YsTUFBTSxDQUFDRyxPQUFPLENBQUNDLEVBQUUsQ0FBQztZQUUzRCxJQUFHLENBQUNILEtBQUssRUFBRTtnQkFDVEYsS0FBSyxDQUFDSixXQUFXLENBQUNVLElBQUksQ0FBQ0wsTUFBTSxDQUFDRyxPQUFPLENBQUNDLEVBQUUsQ0FBQyxDQUFDO2dCQUUxQyxPQUFPO29CQUNMLEdBQUdMLEtBQUs7b0JBQ1JKLFdBQVcsRUFBRUksS0FBSyxDQUFDSixXQUFXO2lCQUMvQixDQUFDO2FBQ0g7WUFFREwsOENBQU0sQ0FBQ1MsS0FBSyxDQUFDSixXQUFXLEVBQUVTLENBQUFBLEVBQUUsR0FBSUEsRUFBRSxLQUFLSixNQUFNLENBQUNHLE9BQU8sQ0FBQ0MsRUFBRTtZQUFBLENBQUMsQ0FBQztZQUUxRCxPQUFPO2dCQUNMLEdBQUdMLEtBQUs7Z0JBQ1JKLFdBQVcsRUFBRUksS0FBSyxDQUFDSixXQUFXO2FBQy9CLENBQUM7U0FDSDtLQUNGO0NBQ0YsQ0FBQztBQUVLLE1BQU0sRUFBRUcsZ0JBQWdCLEdBQUVRLGFBQWEsR0FBRSxHQUFHVixTQUFTLENBQUNXLE9BQU87QUFDcEUsaUVBQWVYLFNBQVMsQ0FBQ1ksT0FBTyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtZWNvbW1lcmNlLy4vc3RvcmUvcmVkdWNlcnMvdXNlci50cz82NzdhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHJlbW92ZSB9IGZyb20gJ2xvZGFzaCc7XHJcblxyXG5pbXBvcnQgeyBjcmVhdGVTbGljZSwgUGF5bG9hZEFjdGlvbiB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnXHJcblxyXG50eXBlIFByb2R1Y3RUeXBlID0ge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIHRodW1iOiBzdHJpbmc7XHJcbiAgcHJpY2U6IHN0cmluZztcclxuICBjb3VudDogbnVtYmVyO1xyXG4gIGNvbG9yOiBzdHJpbmc7XHJcbiAgc2l6ZTogc3RyaW5nO1xyXG59XHJcblxyXG50eXBlIFRvZ2dsZUZhdlR5cGUgPSB7XHJcbiAgaWQ6IHN0cmluZztcclxufVxyXG5cclxuaW50ZXJmYWNlIFVzZXJTbGljZVR5cGVzIHtcclxuICB1c2VyOiBhbnk7XHJcbiAgZmF2UHJvZHVjdHM6IGFueTtcclxufVxyXG5cclxuY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gIHVzZXI6IHtcclxuICAgIG5hbWU6ICdMdWNhcyBQdWxsaWVzZScsXHJcbiAgfSxcclxuICBmYXZQcm9kdWN0czogW10sXHJcbn0gYXMgVXNlclNsaWNlVHlwZXNcclxuXHJcbmNvbnN0IHVzZXJTbGljZSA9IGNyZWF0ZVNsaWNlKHtcclxuICBuYW1lOiAndXNlcicsXHJcbiAgaW5pdGlhbFN0YXRlLFxyXG4gIHJlZHVjZXJzOiB7XHJcbiAgICB0b2dnbGVGYXZQcm9kdWN0KHN0YXRlLCBhY3Rpb246IFBheWxvYWRBY3Rpb248VG9nZ2xlRmF2VHlwZT4pIHtcclxuICAgICAgY29uc3QgaW5kZXggPSBzdGF0ZS5mYXZQcm9kdWN0cy5pbmNsdWRlcyhhY3Rpb24ucGF5bG9hZC5pZCk7XHJcblxyXG4gICAgICBpZighaW5kZXgpIHtcclxuICAgICAgICBzdGF0ZS5mYXZQcm9kdWN0cy5wdXNoKGFjdGlvbi5wYXlsb2FkLmlkKTtcclxuXHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZW1vdmUoc3RhdGUuZmF2UHJvZHVjdHMsIGlkID0+IGlkID09PSBhY3Rpb24ucGF5bG9hZC5pZCk7XHJcbiAgICB9LFxyXG4gICAgc2V0VXNlckxvZ2dlZChzdGF0ZSwgYWN0aW9uOiBQYXlsb2FkQWN0aW9uPFByb2R1Y3RUeXBlPikge1xyXG4gICAgICBjb25zdCBpbmRleCA9IHN0YXRlLmZhdlByb2R1Y3RzLmluY2x1ZGVzKGFjdGlvbi5wYXlsb2FkLmlkKTtcclxuXHJcbiAgICAgIGlmKCFpbmRleCkge1xyXG4gICAgICAgIHN0YXRlLmZhdlByb2R1Y3RzLnB1c2goYWN0aW9uLnBheWxvYWQuaWQpO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICBmYXZQcm9kdWN0czogc3RhdGUuZmF2UHJvZHVjdHNcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZW1vdmUoc3RhdGUuZmF2UHJvZHVjdHMsIGlkID0+IGlkID09PSBhY3Rpb24ucGF5bG9hZC5pZCk7XHJcbiAgICAgIFxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGZhdlByb2R1Y3RzOiBzdGF0ZS5mYXZQcm9kdWN0c1xyXG4gICAgICB9O1xyXG4gICAgfSxcclxuICB9LFxyXG59KVxyXG5cclxuZXhwb3J0IGNvbnN0IHsgdG9nZ2xlRmF2UHJvZHVjdCwgc2V0VXNlckxvZ2dlZCB9ID0gdXNlclNsaWNlLmFjdGlvbnNcclxuZXhwb3J0IGRlZmF1bHQgdXNlclNsaWNlLnJlZHVjZXIiXSwibmFtZXMiOlsicmVtb3ZlIiwiY3JlYXRlU2xpY2UiLCJpbml0aWFsU3RhdGUiLCJ1c2VyIiwibmFtZSIsImZhdlByb2R1Y3RzIiwidXNlclNsaWNlIiwicmVkdWNlcnMiLCJ0b2dnbGVGYXZQcm9kdWN0Iiwic3RhdGUiLCJhY3Rpb24iLCJpbmRleCIsImluY2x1ZGVzIiwicGF5bG9hZCIsImlkIiwicHVzaCIsInNldFVzZXJMb2dnZWQiLCJhY3Rpb25zIiwicmVkdWNlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./store/reducers/user.ts\n");

/***/ }),

/***/ "./utils/gtag.ts":
/*!***********************!*\
  !*** ./utils/gtag.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"GA_TRACKING_ID\": () => (/* binding */ GA_TRACKING_ID),\n/* harmony export */   \"event\": () => (/* binding */ event),\n/* harmony export */   \"pageview\": () => (/* binding */ pageview)\n/* harmony export */ });\nconst GA_TRACKING_ID = \"UA-114361661-6\" // This is your GA Tracking ID\n;\n// https://developers.google.com/analytics/devguides/collection/gtagjs/pages\nconst pageview = (url)=>{\n    window.gtag(\"config\", GA_TRACKING_ID, {\n        page_path: url\n    });\n};\n// https://developers.google.com/analytics/devguides/collection/gtagjs/events\nconst event = ({ action , category , label , value  })=>{\n    window.gtag(\"event\", action, {\n        event_category: category,\n        event_label: label,\n        value: value\n    });\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi91dGlscy9ndGFnLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUVPLE1BQU1BLGNBQWMsR0FBR0MsZ0JBQW9DLENBQUMsOEJBQThCO0FBQS9CO0FBR2xFLDRFQUE0RTtBQUNyRSxNQUFNRyxRQUFRLEdBQUcsQ0FBQ0MsR0FBVyxHQUFLO0lBQ3ZDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxRQUFRLEVBQUVQLGNBQWMsRUFBRTtRQUNwQ1EsU0FBUyxFQUFFSCxHQUFHO0tBQ2YsQ0FBQztDQUNIO0FBRUQsNkVBQTZFO0FBQ3RFLE1BQU1JLEtBQUssR0FBRyxDQUFDLEVBQUVDLE1BQU0sR0FBRUMsUUFBUSxHQUFFQyxLQUFLLEdBQUVDLEtBQUssR0FBaUIsR0FBSztJQUMxRVAsTUFBTSxDQUFDQyxJQUFJLENBQUMsT0FBTyxFQUFFRyxNQUFNLEVBQUU7UUFDM0JJLGNBQWMsRUFBRUgsUUFBUTtRQUN4QkksV0FBVyxFQUFFSCxLQUFLO1FBQ2xCQyxLQUFLLEVBQUVBLEtBQUs7S0FDYixDQUFDO0NBQ0giLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LWVjb21tZXJjZS8uL3V0aWxzL2d0YWcudHM/MTBkMSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHdGFnRXZlbnRUeXBlIH0gZnJvbSAndHlwZXMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IEdBX1RSQUNLSU5HX0lEID0gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQU5BTFlUSUNTX0lEIC8vIFRoaXMgaXMgeW91ciBHQSBUcmFja2luZyBJRFxyXG5kZWNsYXJlIHZhciB3aW5kb3c6IGFueVxyXG5cclxuLy8gaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vYW5hbHl0aWNzL2Rldmd1aWRlcy9jb2xsZWN0aW9uL2d0YWdqcy9wYWdlc1xyXG5leHBvcnQgY29uc3QgcGFnZXZpZXcgPSAodXJsOiBzdHJpbmcpID0+IHtcclxuICB3aW5kb3cuZ3RhZygnY29uZmlnJywgR0FfVFJBQ0tJTkdfSUQsIHtcclxuICAgIHBhZ2VfcGF0aDogdXJsLFxyXG4gIH0pXHJcbn1cclxuXHJcbi8vIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL2FuYWx5dGljcy9kZXZndWlkZXMvY29sbGVjdGlvbi9ndGFnanMvZXZlbnRzXHJcbmV4cG9ydCBjb25zdCBldmVudCA9ICh7IGFjdGlvbiwgY2F0ZWdvcnksIGxhYmVsLCB2YWx1ZSB9OiBHdGFnRXZlbnRUeXBlKSA9PiB7XHJcbiAgd2luZG93Lmd0YWcoJ2V2ZW50JywgYWN0aW9uLCB7XHJcbiAgICBldmVudF9jYXRlZ29yeTogY2F0ZWdvcnksXHJcbiAgICBldmVudF9sYWJlbDogbGFiZWwsXHJcbiAgICB2YWx1ZTogdmFsdWUsXHJcbiAgfSlcclxufSJdLCJuYW1lcyI6WyJHQV9UUkFDS0lOR19JRCIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19BTkFMWVRJQ1NfSUQiLCJwYWdldmlldyIsInVybCIsIndpbmRvdyIsImd0YWciLCJwYWdlX3BhdGgiLCJldmVudCIsImFjdGlvbiIsImNhdGVnb3J5IiwibGFiZWwiLCJ2YWx1ZSIsImV2ZW50X2NhdGVnb3J5IiwiZXZlbnRfbGFiZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./utils/gtag.ts\n");

/***/ }),

/***/ "./assets/css/styles.scss":
/*!********************************!*\
  !*** ./assets/css/styles.scss ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/rc-slider/assets/index.css":
/*!*************************************************!*\
  !*** ./node_modules/rc-slider/assets/index.css ***!
  \*************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/react-rater/lib/react-rater.css":
/*!******************************************************!*\
  !*** ./node_modules/react-rater/lib/react-rater.css ***!
  \******************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/swiper/swiper.scss":
/*!*****************************************!*\
  !*** ./node_modules/swiper/swiper.scss ***!
  \*****************************************/
/***/ (() => {



/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ "next-redux-wrapper":
/*!*************************************!*\
  !*** external "next-redux-wrapper" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "redux-persist":
/*!********************************!*\
  !*** external "redux-persist" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ "redux-persist/lib/storage":
/*!********************************************!*\
  !*** external "redux-persist/lib/storage" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/lib/storage");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();